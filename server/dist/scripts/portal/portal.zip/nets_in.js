function enter(pi) {
	pi.saveLocation("MULUNG_TC");
	pi.warp(926010000, 0);
	return true;
}