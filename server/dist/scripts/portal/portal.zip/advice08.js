function enter(pi) {
	pi.showInstruction("Voce pode verificar as estatisticas do seu personagem, pressionando o #e#b[S]#k#nkey.", 350, 5);
	return true;
}