function enter(pi) {
	pi.playPortalSE();
	pi.warp(900010100, "st00");
	return true;
}