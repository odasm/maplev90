function enter(pi) {
    pi.warp(682000000,0);
}