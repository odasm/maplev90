function enter(pi) {
	pi.openNpc(1052115);
	return true;
}