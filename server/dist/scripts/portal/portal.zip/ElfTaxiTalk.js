function enter(pi) {
    pi.openNpc(1033112);
}