function enter(pi) {
	pi.warp(240060000, "st00");
	return true;
}