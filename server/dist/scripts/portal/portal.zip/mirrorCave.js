function enter(pi) {
    pi.warp(914021000,0);
 //what does this even do
}