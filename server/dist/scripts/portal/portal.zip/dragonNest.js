function enter(pi) {
	pi.warp(240040611, "out00");
	return true;
}