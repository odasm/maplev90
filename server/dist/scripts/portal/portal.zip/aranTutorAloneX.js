function enter(pi) {
    pi.playPortalSE();
    pi.warp(914000100, 1);
}