function enter(pi) {
	pi.warp(240020101, "out00");
	return true;
}