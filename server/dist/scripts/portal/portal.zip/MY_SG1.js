function enter(pi) {
    pi.warp(551000100,1);
}