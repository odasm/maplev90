function enter(pi) {
	pi.saveLocation("MULUNG_TC");
	pi.warp(610010000, 0);
	return true;
}