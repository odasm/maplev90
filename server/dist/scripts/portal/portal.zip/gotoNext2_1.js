function enter(pi) {
	pi.playPortalSE();
    pi.warp(211060500, 1);
	return true;
}