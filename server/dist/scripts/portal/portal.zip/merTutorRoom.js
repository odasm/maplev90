function enter(pi) {
	if (pi.isQuestFinished(24002)) {
		pi.warp(910150004,0);
	}
}