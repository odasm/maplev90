function enter(pi) {
    pi.openNpc(9250143);
}