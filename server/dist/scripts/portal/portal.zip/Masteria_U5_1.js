
function enter(pi) {
	if (pi.itemQuantity(3992040) > 0) {
		pi.warp(610010001, "sU2_1");
		return false;
	}
	return true;
}