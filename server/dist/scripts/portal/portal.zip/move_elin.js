function enter(pi) {
    pi.playPortalSE();
    pi.warp(300000100, "out00");
    return true;
}