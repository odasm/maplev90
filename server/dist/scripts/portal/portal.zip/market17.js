/*
Created by Cody/Cyndicate and Nick.

Nautilus Port - FM Portal
*/

importPackage(Packages.server.maps);

function enter(pn) {
		pn.warp(910000000, "sp");
		return true;
}