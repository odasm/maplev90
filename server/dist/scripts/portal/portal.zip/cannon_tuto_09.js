function enter(pi) {
    pi.sendDirectionStatus(3, 0);
	pi.sendDirectionStatus(4, 1096005);
	pi.openNpc(1096005);
}