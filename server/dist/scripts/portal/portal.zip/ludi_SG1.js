function enter(pi) {
    pi.warp(220070000,5);
}