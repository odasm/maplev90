function enter(pi) {
	pi.showInstruction("Voce pode ver o mapa do mundo, pressionando a #e#b[W]#k#nkey.", 350, 5);
	return true;
}