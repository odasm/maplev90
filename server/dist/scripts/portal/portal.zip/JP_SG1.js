function enter(pi) {
    pi.warp(800040200,0);
}