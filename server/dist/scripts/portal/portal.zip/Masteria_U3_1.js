
function enter(pi) {
	if (pi.itemQuantity(3992040) > 0) {
		pi.warp(610010201, "sB2_1");
		return false;
	}
	return true;
}