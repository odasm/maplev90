/*
Forest East of Henesys (100030000) - Entrance Map Nautilus Harbor (120010000)
@Author Malefic
*/
function enter(pi) {
    pi.warp(120010000, "nt01");
    return true;
}  