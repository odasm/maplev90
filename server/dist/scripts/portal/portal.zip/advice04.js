function enter(pi) {
	pi.showInstruction("Este e o melhor servidor de MapleStory classico do mundo! ", 250, 5);
	return true;
}