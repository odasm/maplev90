function enter(pi) {
	pi.warp(502010010);
	return true;
}