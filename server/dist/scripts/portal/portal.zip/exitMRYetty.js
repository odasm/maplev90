function enter(pi) {
    
	pi.openNpc(2110005);

}