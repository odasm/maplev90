function enter(pi) {
	pi.warp(240010501, "out00");
	return true;
}