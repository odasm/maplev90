function enter(pi) {
    pi.openNpc(9001001);
}