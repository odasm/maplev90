function enter(pi) {
	pi.playerMessage("Ele parece estar bloqueado.");
	return true;
}