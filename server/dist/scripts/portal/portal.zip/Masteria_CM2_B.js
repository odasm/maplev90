
function enter(pi) {
	if (pi.itemQuantity(3992039) > 0) {
		pi.warp(610020001, "CM2_C");
		return false;
	}
	return true;
}