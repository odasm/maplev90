function enter(pi) {
    pi.playPortalSE();
    pi.warp(800040410, "out00");
    return true;
}