
function enter(pi) {
	if (pi.itemQuantity(3992039) > 0) {
		pi.warp(610020000, "CM1_B");
		return false;
	}
	return true;
}