function enter(pi) {
    pi.warp(600020000,7);
}