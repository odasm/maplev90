function enter(pi) {
    pi.showInstruction("Press #e#b[Q]#k#n to view the Quest window.", 250, 5);
}