function enter(pi) {
	pi.playPortalSE();
    pi.warp(100000201, 0);
	return true;
}