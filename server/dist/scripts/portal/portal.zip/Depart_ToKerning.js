/* 
  Original name: Depart_ToKerning. 
  Map(s): Kerning Square Station (103000310). 
  Duties: Takes you back to kerning from kerning square. 
*/ 

function enter(pi) { 
 pi.getPlayer().timedRide(103000300, 103000100, "The next stop is at Kerning Subway Station. The exit is on your left.", 10000); 
 return true; 
}  