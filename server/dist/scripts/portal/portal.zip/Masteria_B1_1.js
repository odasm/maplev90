
function enter(pi) {
	if (pi.itemQuantity(3992040) > 0) {
		pi.warp(610010005, "sU6_1");
		return true;
	}
	return false;
}