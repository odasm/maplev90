function enter(pi) {
	if (pi.isQuestFinished(1035))
		pi.ShowWZEffect("UI/tutorial.img/23");
	return false;
}