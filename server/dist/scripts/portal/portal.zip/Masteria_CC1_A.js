
function enter(pi) {
	pi.warp(610020015, "CC6_A");
	return true;
}