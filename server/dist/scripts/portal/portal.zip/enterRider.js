function enter(pi) {
    pi.playerMessage(5, "This portal is unavailable. If you wish to get a mount, please purchase one.");
}