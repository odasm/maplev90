function enter(pi) {
	if (pi.isQuestActive(1031)){
		pi.ShowWZEffect("UI/tutorial.img/25");
		return true;
	}
return false;
}