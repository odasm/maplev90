importPackage(Packages.server.maps);
importPackage(Packages.net.channel);
importPackage(Packages.tools);


function enter(pi) {
		pi.warp(920011000, 1); //Storage
		return true;
}