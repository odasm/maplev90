function enter(pi) {
	pi.playPortalSE();
    pi.warp(211060700, 1); // Lion King's Castle: Under the Castle Walls 4
	return true;
}