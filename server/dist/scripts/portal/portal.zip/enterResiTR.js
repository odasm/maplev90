function enter(pi) {
    pi.openNpc(2151007);
	return true;
}