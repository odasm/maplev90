
function enter(pi) {
	if (pi.itemQuantity(3992040) > 0) {
		pi.warp(610010002, "sU3_1");
		return false;
	}
	return true;
}