function enter(pi) {
	pi.warp(260000301, "out00");
	return true;
}
