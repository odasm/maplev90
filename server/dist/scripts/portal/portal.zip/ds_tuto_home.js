function enter(pi) {
        pi.ShowWZEffect("Effect/OnUserEff.img/normalEffect/demonSlayer/chatBalloon" + pi.getPortal().getName().substring(pi.getPortal().getName().length() - 1, pi.getPortal().getName().length()));
}