function enter(pi) {
	pi.playPortalSE();
    pi.warp(211060610, 1); //  Lion King's Castle: Short Castle Walls 2
	return true;
}